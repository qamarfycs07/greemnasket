from django.apps import AppConfig


class SalerConfig(AppConfig):
    name = 'saler'
